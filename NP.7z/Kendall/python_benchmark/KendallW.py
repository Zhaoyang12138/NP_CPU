import pandas as pd
from scipy.stats import 
import numpy as np

def KendallW(random_arr):