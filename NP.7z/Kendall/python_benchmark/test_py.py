import numpy as np
import pandas as pd
from scipy.stats import spearmanr, mannwhitneyu, wilcoxon, friedmanchisquare, kruskal
from ManWhitneyu_ import ManWhitneyu
from Wilconxon_ import Wilcoxon
from Friedman_ import Friedman
from Kruskal_ import Kruskal
from Kendall_ import Kendall
from Brown_ import Brown
from Spearman_ import spearman

arr_nums = [256, 512, 1024, 2048, 4096, 8192]
arr_sizes = [128, 256, 512, 1024, 2048, 4096, 8192]

# 设置随机种子
np.random.seed(42)
# 设置数组大小
arr_num = arr_nums[4]
arr_size = arr_sizes[-3]
# 初始化一个随机数组
min_val = 0
max_val = 2**32 - 1
random_arr = np.random.randint(min_val, max_val, size=(arr_num, arr_size), dtype=np.uint32)
print(arr_num, arr_size)
print(random_arr.shape)

# # kendall检验
# Kendall(random_arr)

# spearman检验
spearman(random_arr)

# Mann检验
ManWhitneyu(random_arr)

# wilcoxon检验
Wilcoxon(random_arr)

# Friedman检验
Friedman(random_arr)

# Kruskal检验
Kruskal(random_arr)

# KendallW检验


# BrownForsythe检验
Brown(random_arr)
