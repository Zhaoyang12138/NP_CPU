function levene_res =  Levene(random_arr)
% 
    alpha = 0.05; % 显著性水平
    [m, n] = size(random_arr);
    

    