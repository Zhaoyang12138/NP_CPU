function Kendall_res = Kendall_(random_arr)
    % 计算矩阵数据的Spearman相关系数
    arr = im2double(random_arr');
    
    disp('start Kendall test');

    tic;
    Kendall_res = corr(arr, 'type', 'Kendall');
    toc;

    fprintf('end Kendall test\n\n');
    disp(size(Kendall_res));
    
    end